wc -l "$@" | sort -n
